class ChallengeCreateException(Exception):
    pass


class ChallengeUpdateException(Exception):
    pass
