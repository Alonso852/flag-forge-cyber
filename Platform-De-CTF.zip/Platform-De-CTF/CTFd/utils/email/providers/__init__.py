class EmailProvider:
    @staticmethod
    def sendmail(addr, text, subject):
        raise NotImplementedError
